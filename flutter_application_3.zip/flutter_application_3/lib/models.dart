class Moneda {
  final int? id;
  final String nombre;
  final String codigo;

  const Moneda({this.id, required this.nombre, required this.codigo});

  factory Moneda.fromJson(Map<String, dynamic> json) {
    final codigo = json['codigo'] ?? json['code'] ?? json['abreviacion'] ?? json['nombre'] ?? json['name'] ?? '';
    final nombre = json['nombre'] ?? json['name'] ?? json['descripcion'] ?? codigo.toString();
    return Moneda(
      id: json['id'] is int ? json['id'] as int : int.tryParse('${json['id'] ?? ''}'),
      nombre: nombre.toString(),
      codigo: codigo.toString(),
    );
  }
}

class CambioMoneda {
  final String fecha;
  final dynamic valor;

  const CambioMoneda({required this.fecha, required this.valor});

  factory CambioMoneda.fromJson(Map<String, dynamic> json) {
    final fecha = json['fecha'] ?? json['date'] ?? json['dia'] ?? '';
    final valor = json['valor'] ?? json['value'] ?? json['tipoCambio'] ?? json['tipo_cambio'] ?? '';
    return CambioMoneda(fecha: fecha.toString(), valor: valor);
  }
}
