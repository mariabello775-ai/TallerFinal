import 'dart:convert';
import 'package:http/http.dart' as http;

import 'models.dart';

class ApiService {
  ApiService({this.baseUrl = 'http://localhost:8080'});

  final String baseUrl;

  Future<String> login(String usuario, String clave) async {
    final uri = Uri.parse('$baseUrl/api/usuarios/validar/$usuario/$clave');
    final response = await http.get(uri);

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('Usuario o contraseña incorrectos');
    }

    final body = response.body.trim();
    if (body.isEmpty) throw Exception('La API no devolvió un token');

    try {
      final decoded = jsonDecode(body);
      if (decoded is Map<String, dynamic>) {
        final token = decoded['token'] ?? decoded['accessToken'] ?? decoded['jwt'] ?? decoded['clave'];
        if (token != null) return token.toString();
      }
    } catch (_) {
      // Algunas APIs devuelven el token como texto plano.
    }
    return body;
  }

  Future<List<Moneda>> listarMonedas(String token) async {
    final uri = Uri.parse('$baseUrl/api/monedas/listar');
    final response = await http.get(uri, headers: _headers(token));

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('No se pudieron obtener las monedas (${response.statusCode})');
    }

    final decoded = jsonDecode(response.body);
    final List<dynamic> items = decoded is List
        ? decoded
        : decoded is Map<String, dynamic>
            ? (decoded['content'] ?? decoded['monedas'] ?? decoded['data'] ?? []) as List<dynamic>
            : [];
    return items
        .whereType<Map<String, dynamic>>()
        .map(Moneda.fromJson)
        .toList();
  }

  Future<List<CambioMoneda>> listarCambios({
    required String token,
    required String moneda,
    required DateTime inicio,
    required DateTime fin,
  }) async {
    final id = moneda;
    final desde = _fecha(inicio);
    final hasta = _fecha(fin);
    final candidates = <Uri>[
      Uri.parse('$baseUrl/api/monedas/listarporperiodo/$id/$desde/$hasta'),
      Uri.parse('$baseUrl/api/monedas/listarporperiodo').replace(queryParameters: {
        'id': id,
        'fechaInicio': desde,
        'fechaFin': hasta,
      }),
    ];

    for (final uri in candidates) {
      final response = await http.get(uri, headers: _headers(token));
      if (response.statusCode < 200 || response.statusCode >= 300) continue;

      final decoded = jsonDecode(response.body);
      final List<dynamic> items = decoded is List
          ? decoded
          : decoded is Map<String, dynamic>
              ? (decoded['content'] ?? decoded['cambios'] ?? decoded['data'] ?? []) as List<dynamic>
              : [];
      return items
          .whereType<Map<String, dynamic>>()
          .map(CambioMoneda.fromJson)
          .toList();
    }

    throw Exception('No se encontraron cambios en el período seleccionado');
  }

  Map<String, String> _headers(String token) => {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      };

  String _fecha(DateTime date) {
    final year = date.year.toString().padLeft(4, '0');
    final month = date.month.toString().padLeft(2, '0');
    final day = date.day.toString().padLeft(2, '0');
    return '$year-$month-$day';
  }
}
