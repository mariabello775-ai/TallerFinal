import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import 'api_service.dart';
import 'models.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Consulta de monedas',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.teal),
        useMaterial3: true,
      ),
      home: const LoginPage(),
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _formKey = GlobalKey<FormState>();
  final _usuarioController = TextEditingController();
  final _claveController = TextEditingController();
  late final ApiService _api;
  bool _loading = false;
  bool _verClave = false;

  @override
  void initState() {
    super.initState();
    final host = kIsWeb || defaultTargetPlatform != TargetPlatform.android
        ? 'localhost'
        : '10.0.2.2';
    _api = ApiService(baseUrl: 'http://$host:8080');
  }

  @override
  void dispose() {
    _usuarioController.dispose();
    _claveController.dispose();
    super.dispose();
  }

  Future<void> _login() async {
    if (!(_formKey.currentState?.validate() ?? false)) return;

    setState(() => _loading = true);
    try {
      final token = await _api.login(
        _usuarioController.text.trim(),
        _claveController.text,
      );
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (_) => ConsultaPage(api: _api, token: token),
        ),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(error.toString().replaceFirst('Exception: ', ''))),
      );
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 420),
            child: Card(
              elevation: 3,
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Form(
                  key: _formKey,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.currency_exchange, size: 64, color: Colors.teal),
                      const SizedBox(height: 12),
                      Text('Ingreso', style: Theme.of(context).textTheme.headlineMedium),
                      const SizedBox(height: 24),
                      TextFormField(
                        controller: _usuarioController,
                        decoration: const InputDecoration(
                          labelText: 'Usuario',
                          prefixIcon: Icon(Icons.person),
                          border: OutlineInputBorder(),
                        ),
                        validator: (value) => value == null || value.trim().isEmpty
                            ? 'Ingrese el usuario'
                            : null,
                      ),
                      const SizedBox(height: 16),
                      TextFormField(
                        controller: _claveController,
                        obscureText: !_verClave,
                        decoration: InputDecoration(
                          labelText: 'Clave',
                          prefixIcon: const Icon(Icons.lock),
                          border: const OutlineInputBorder(),
                          suffixIcon: IconButton(
                            onPressed: () => setState(() => _verClave = !_verClave),
                            icon: Icon(_verClave ? Icons.visibility_off : Icons.visibility),
                          ),
                        ),
                        onFieldSubmitted: (_) => _login(),
                        validator: (value) => value == null || value.isEmpty
                            ? 'Ingrese la clave'
                            : null,
                      ),
                      const SizedBox(height: 24),
                      SizedBox(
                        width: double.infinity,
                        height: 48,
                        child: FilledButton(
                          onPressed: _loading ? null : _login,
                          child: _loading
                              ? const SizedBox(
                                  width: 22,
                                  height: 22,
                                  child: CircularProgressIndicator(strokeWidth: 2),
                                )
                              : const Text('INICIAR SESIÓN'),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class ConsultaPage extends StatefulWidget {
  const ConsultaPage({super.key, required this.api, required this.token});

  final ApiService api;
  final String token;

  @override
  State<ConsultaPage> createState() => _ConsultaPageState();
}

class _ConsultaPageState extends State<ConsultaPage> {
  List<Moneda> _monedas = [];
  Moneda? _moneda;
  List<CambioMoneda> _cambios = [];
  DateTime _inicio = DateTime.now().subtract(const Duration(days: 30));
  DateTime _fin = DateTime.now();
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _cargarMonedas();
  }

  Future<void> _cargarMonedas() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final monedas = await widget.api.listarMonedas(widget.token);
      if (!mounted) return;
      setState(() {
        _monedas = monedas;
        _moneda = monedas.isNotEmpty ? monedas.first : null;
        _loading = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _error = error.toString().replaceFirst('Exception: ', '');
        _loading = false;
      });
    }
  }

  Future<void> _consultar() async {
    if (_moneda == null) {
      _mostrarError('Seleccione una moneda');
      return;
    }
    if (_fin.isBefore(_inicio)) {
      _mostrarError('La fecha final no puede ser anterior a la inicial');
      return;
    }

    setState(() {
      _loading = true;
      _error = null;
      _cambios = [];
    });
    try {
      final id = _moneda!.id?.toString() ?? _moneda!.codigo;
      final cambios = await widget.api.listarCambios(
        token: widget.token,
        moneda: id,
        inicio: _inicio,
        fin: _fin,
      );
      if (!mounted) return;
      setState(() {
        _cambios = cambios;
        _loading = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _error = error.toString().replaceFirst('Exception: ', '');
        _loading = false;
      });
    }
  }

  void _mostrarError(String mensaje) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(mensaje)));
  }

  Future<void> _elegirFecha(bool inicio) async {
    final actual = inicio ? _inicio : _fin;
    final seleccionada = await showDatePicker(
      context: context,
      initialDate: actual,
      firstDate: DateTime(2000),
      lastDate: DateTime.now(),
    );
    if (seleccionada == null) return;
    setState(() {
      if (inicio) {
        _inicio = seleccionada;
      } else {
        _fin = seleccionada;
      }
    });
  }

  String _fecha(DateTime date) =>
      '${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Consulta de cambios'),
        actions: [
          IconButton(
            tooltip: 'Cerrar sesión',
            onPressed: () {
              Navigator.of(context).pushReplacement(
                MaterialPageRoute(builder: (_) => const LoginPage()),
              );
            },
            icon: const Icon(Icons.logout),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 700),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        DropdownButtonFormField<Moneda>(
                          isExpanded: true,
                          initialValue: _moneda,
                          decoration: const InputDecoration(
                            labelText: 'Moneda',
                            border: OutlineInputBorder(),
                          ),
                          items: _monedas
                              .map((moneda) => DropdownMenuItem(
                                    value: moneda,
                                    child: Text('${moneda.nombre} (${moneda.codigo})'),
                                  ))
                              .toList(),
                          onChanged: _loading
                              ? null
                              : (value) => setState(() => _moneda = value),
                        ),
                        const SizedBox(height: 16),
                        Row(
                          children: [
                            Expanded(
                              child: OutlinedButton.icon(
                                onPressed: () => _elegirFecha(true),
                                icon: const Icon(Icons.calendar_today),
                                label: Text('Desde: ${_fecha(_inicio)}'),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: OutlinedButton.icon(
                                onPressed: () => _elegirFecha(false),
                                icon: const Icon(Icons.calendar_today),
                                label: Text('Hasta: ${_fecha(_fin)}'),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 16),
                        FilledButton.icon(
                          onPressed: _loading ? null : _consultar,
                          icon: const Icon(Icons.search),
                          label: const Text('CONSULTAR CAMBIOS'),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                if (_loading)
                  const Padding(
                    padding: EdgeInsets.all(32),
                    child: Center(child: CircularProgressIndicator()),
                  )
                else if (_error != null)
                  Card(
                    color: Theme.of(context).colorScheme.errorContainer,
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Text(
                        _error!,
                        style: TextStyle(
                          color: Theme.of(context).colorScheme.onErrorContainer,
                        ),
                      ),
                    ),
                  )
                else if (_cambios.isEmpty)
                  const Card(
                    child: Padding(
                      padding: EdgeInsets.all(24),
                      child: Text(
                        'No hay cambios para mostrar.',
                        textAlign: TextAlign.center,
                      ),
                    ),
                  )
                else
                  Card(
                    child: ListView.separated(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: _cambios.length,
                      separatorBuilder: (_, index) => const Divider(height: 1),
                      itemBuilder: (context, index) {
                        final cambio = _cambios[index];
                        return ListTile(
                          leading: const Icon(Icons.payments_outlined),
                          title: Text(cambio.fecha),
                          trailing: Text(
                            '${cambio.valor}',
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                        );
                      },
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
